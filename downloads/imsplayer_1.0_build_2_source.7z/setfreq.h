#ifndef __SETFREQ_H_
#define __SETFREQ_H_

#ifdef __cplusplus
extern "C" {
#endif

int SetFreq(short voice, unsigned short note, short pitch, short keyOn);

#ifdef __cplusplus
}
#endif

#endif	//__SETFREQ_H_
